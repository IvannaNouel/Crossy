﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class jugador : MonoBehaviour
{
    private Animator animator;
    private bool saltando;

    public void Start()
    {
        animator = GetComponent<Animator>();
    }

    public void Update()
    {

        if (Input.GetKeyDown(KeyCode.W) && !saltando)
        {
            animator.SetTrigger("Salto");
            saltando = true;

            float Zdiff = 0;
            if (transform.position.z % 1 != 0)
            {
                Zdiff = Mathf.Round(transform.position.z) - transform.position.z;

            }
            transform.position = (transform.position + new Vector3(1, 0, Zdiff));
        }
        else if(Input.GetKeyDown(KeyCode.A) && !saltando) {
            animator.SetTrigger("Salto");
            saltando = true;

        }

    }
    public void DejaElSalto()
    {
        saltando = false;

    }
}
