﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "TodoTerreno", menuName = "ToditoTerreno")]
public class TodoTerreno : ScriptableObject
{

    public GameObject terreno;
    public int maxInSuccesion;
}
