using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class startPoint : MonoBehaviour


{

    [SerializeField] private int maxTerrenoC;
    [SerializeField] private List<TodoTerreno> TodoTerrenito = new List<TodoTerreno>();
    [SerializeField] private Transform terrenoH;

    private List<GameObject> now = new List<GameObject>();

    private Vector3 currentPosition = new Vector3(0, 0, 0);


#pragma warning disable IDE0051 // Remove unused private members
    private void Start()
#pragma warning restore IDE0051 // Remove unused private members

    {

        for (int i=0; i < maxTerrenoC; i++)
        {
            Comienzo(true);

        }
        maxTerrenoC = now.Count;


    }
#pragma warning disable IDE0051 // Remove unused private members
    private void Update()
#pragma warning restore IDE0051 // Remove unused private members
    {
        if (Input.GetKeyDown(KeyCode.W))
        {

            Comienzo(false);


        }

    }

    private void Comienzo(bool isComienzo)
    {
        int enTerreno = Random.Range(0, TodoTerrenito.Count);
        int terrenoEnSuccesion = Random.Range(1,TodoTerrenito[enTerreno].maxInSuccesion);
        for (int i = 0; i < terrenoEnSuccesion; i++)
        {

            GameObject terreno = Instantiate(TodoTerrenito[enTerreno].terreno, currentPosition, Quaternion.identity, terrenoH);
            now.Add(terreno);

            if (!isComienzo)
            {
                if (now.Count > maxTerrenoC)
                {
                    Destroy(now[0]);
                    now.RemoveAt(0);
                }
            }
            currentPosition.x++;

        }

        /*
        
        */
    }
}